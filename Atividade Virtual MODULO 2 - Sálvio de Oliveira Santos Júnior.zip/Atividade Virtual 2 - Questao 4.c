//Quest�o 04
//Usando o comando de condi��o switch, crie um programa (calculadora) que leia dois n�meros e 
//calcule e imprima a soma, subtra��o, multiplica��o, divis�o e exponencial (xy) destes n�meros.

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

 main()

{
	
	float n1, n2, resultado;
	int num = 0;
	
	printf("\n\tCALCULADORA:\n");
	
	printf("\n\nDigite o 1 numero : \t");
	scanf("%f", &n1);
	
	
	printf("\n\n\tDigite numero de sua opera��o");
	printf("\n1 - Soma");
	printf("\n2 - Subtracao");
	printf("\n3 - Multiplica��o");
	printf("\n4 - Divis�o");
	printf("\n5 - Exponecial\n\n");
	
	
	printf("\nDigite seu operador:\t");
	scanf("%d", &num);
	
	printf("\nDigite o 2 numero : \t");
	scanf("%f", &n2);
	
	switch(num)
	{
		case 1: 
			resultado = n1 + n2;
			printf("\n\nSoma: \t%.2f", resultado);
		break;
		
		case 2:
			resultado = n1 - n2;
			printf("\n\nSubtracao: \t%.2f", resultado);
		break;
		
		case 3:
			resultado = n1 * n2;
			printf("\n\nMultiplicacao: \t%.2f", resultado);
		break;
		
		case 4:
			resultado = n1 / n2;
			if(n2 == 0)
			{
				printf("\nDivisao por zero");
			}
			else
			{
			printf("\n\nDivisao: \t%.2f", resultado);
			}
		break;
		
		case 5:
			resultado = pow((n1), n2);
			printf("\n\nExponecial: \t%.2f", resultado);
		break;
		
		default:
			printf("\nAcabou..\n");
	}
 }
