//Quest�o 01  
//Fa�a um programa em C que leia duas notas, calcule a m�dia e imprima a avalia��o do aluno conforme crit�rio abaixo:
//M�dia < 5 ---> 'Fraco'
//Media <= 5 ---> 'Regular'
//Media <= 8 --> 'Bom'
//Media > 8 ---> 'Excelente'

#include<stdio.h>
#include<stdlib.h>

main()

{
	float nota1 , nota2, media;
	
	printf("Digite a primeira nota:  ");
	scanf("%f", &nota1);
	
	printf("Digite a segunda nota: \t");
	scanf("%f", &nota2);
	
	media = (nota1 + nota2)/ 2;
	
		if ( media < 5)
				printf("\nFRACO\n");
		else 
			if ( media <= 5)
				printf("\nREGULAR\n");
		else 
			if ( media <= 8)
				printf("\nBOM\n");
		else 
		//	if( media > 8)
				printf("\nEXCELENTE\n");
				
	printf("\n\nMedia dos alunos eh = %.2f\n\n", media);
}
