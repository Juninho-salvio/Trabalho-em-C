//Quest�o 02 
//Fa�a um programa na linguagem C que leia o nome, o telefone, os 3 �ltimos sal�rios e exibe a seguintes informa��es:
// Media dos Sal�rios
// Maior Salario
// Menor Salario

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<conio.h>

main()

{
	float sal1, sal2, sal3, media, maior, menor;
	char nome[40], fone[12];
	
//Escrevendo dados como nome e telefone	
	printf("\nDigite o nome do funcionario: \t");
	scanf("%s", &nome);
	printf("\nDigite seu telefone: \t");
	scanf("%s", &fone);
	
//Escrevendo os 3 salarios
	printf("\n\nDgite o 1 salario: \t");
	scanf("%f", &sal1);
	printf("\nDigite o 2 salario: \t");
	scanf("%f", &sal2);
	printf("\nDigite o 3 salario: \t");
	scanf("%f", &sal3);
	
//incluir dados pedidos
	media = ( sal1 + sal2 + sal3)/ 3;
	printf("\n\nMedia Salarial : %.2f", media);
	
//maior salario	
	if (( sal1 > sal2) && ( sal1 > sal3))
	{
		printf ("\nMaior salario e o primeiro = %.2f", sal1);
	}
	else
	{
		if (( sal2 > sal1 ) && (sal2 > sal3)){
			printf("\nMaior salario e o segundo = %.2f", sal2);
	}
	else
	{
		{
			printf("\nMaior salario e o terceiro = %.2f", sal3);
		}
}
}
//Menor salario	
	if (( sal1 < sal2) && (sal1 < sal3))
	{
		printf("\nMenor salario e o primeiro = %.2f", sal1);
	}
	else
	{
		if( ( sal2 < sal1) && (sal2 < sal3)){
			printf("\nMenor salario e o segundo = %.2f", sal2);
		}
	else
		{
		{
			printf("\nMenor salario e o terceiro = %.2f\n", sal3);
		}
	}
}
}
