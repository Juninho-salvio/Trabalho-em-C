//Quest�o 03 
//Fa�a um programa em C que receba um n�mero inteiro e verifique se este n�mero � maior que 35,
//em caso afirmativo o programa dever� imprimir a mensagem: "N�mero maior que 35".

#include<stdio.h>
#include<stdlib.h>

main()

{
	int num;
	
	printf("\nDigite qualquer numero inteiro= \t");
	scanf("%d", &num);
	
	if ( num > 35)
	{
		printf("\n\tNumero maior que 35\n\n");
		}
	else
	{
		printf("\n\tNumero menor ou igual que 35\n\n");
	}

}


