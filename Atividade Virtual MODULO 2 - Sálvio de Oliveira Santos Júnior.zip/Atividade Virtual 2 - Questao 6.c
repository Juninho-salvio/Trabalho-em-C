//Quest�o 06 
//Fa�a um programa em C que leia 10 valores e ao final imprima a m�dia aritm�tica dos valores lidos.

#include<stdio.h>
#include<stdlib.h>

 main()

{
	int valor;
	float numero, soma = 0, media = 0; 
	
	for ( valor = 1; valor <= 10; valor++ )
	{
		printf("\nDigite qualquer valor: \t");
		scanf("%f", &numero);
		
		soma = soma + numero;	
	}

    media = soma / 10;
	printf("\n\nA media dos valores e: \t%.2f\n", media);

}
