//Quest�o 05 
//Segundo uma tabela m�dica, o peso ideal est� relacionado com a altura e o sexo. 
//Fa�a um programa em C que receba a altura e o sexo de uma pessoa, ap�s isso calcule e imprima o seu peso ideal, utilizando as seguintes f�rmulas:
//para homens: (72,7 * A ) - 58
//para mulheres: ( 62,1 * A ) - 44,7      A � a altura

#include<stdio.h>
#include<stdlib.h>

main()

{
    float A, resultado;
    char sexo;
    
    printf("\nDigite sua altura: \t");
    scanf("%f%*c",&A);

    printf("\nDigite seu sexo [F] Feminino ou [M] Masculino: \t");
    scanf("%c%*c",&sexo);

  
    if(sexo =='m'|| sexo =='M')
        {
		resultado = (72.7 * A) - 58;
    	}
    else 
		{
			if(sexo =='f'|| sexo =='F')
        		resultado = (62.1 * A )- 44.7;
		}
	 printf("\nO seu peso ideal eh:%.3f\n", resultado);
	 
	 return 0;
}
