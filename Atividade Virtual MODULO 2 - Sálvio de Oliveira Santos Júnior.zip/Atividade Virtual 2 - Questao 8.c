//Quest�o 08 
//Utilizando o comando do � while, construa um programa em C que leia v�rios n�meros e informe quantos n�meros entre 100 e 160 foram digitados. 
//Quando o valor 0 (zero) for lido, o algoritmo dever� cessar sua execu��o.

#include<stdio.h>
#include<stdlib.h>

main()

{
	int num, contador;
	
	contador = 0;
	
	while(num |= 0)
	{
		printf("\nDigite um numero inteiro = ");
		scanf("%d", &num);
		
		if ( num > 100  &&  num < 160)
		{
			contador = contador + 1;
			}
			}		
			printf("\n\nForam digitados %d numeros entre 100 e 160. \t\n\n", contador);
			
			return  0;
}
