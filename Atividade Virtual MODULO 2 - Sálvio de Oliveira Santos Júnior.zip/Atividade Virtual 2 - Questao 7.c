//Quest�o 07  
//Fa�a um programa que permita entrar com o nome e o sal�rio bruto de 10 pessoas. 
//Ap�s ler os dados, imprimir o nome e o valor da al�quota do imposto de renda calculado conforme a tabela a seguir:

#include<stdio.h>
#include<stdlib.h>

main()

{
	float salario, aliquota;
	int x;
	char nome[50];

	for ( x = 1; x <= 10; x++)
	{
		printf("\nEscreva o nome = \t");

		fflush(stdin);
		fgets(nome,100,stdin);
		
		printf("\nEscreva o salario = R$ \t");
		scanf("%f", &salario);
		
			
		if( salario <= 1300 )
		{
			printf("\nIsento de imposto\n\n");
		}
		else
			{
				if( salario <= 2300 )
				{
				aliquota = (salario * 10) / 100;
				}
		else
			{
				aliquota = ( salario * 15) / 100;
			}	
		printf("\nAliquota = R$ \t %.2f \n\n", aliquota);
	}
	}
 }

